# Source register

The two HTML versions use the same annual mine-production observations. Each pair of world and Chile values comes from the current-year mine-production column of the following year's USGS *Mineral Commodity Summaries* lithium chapter. Values are tonnes of contained Li. Cumulative figures in the CSV are running sums of the annual figures beginning in 1995.

| Production year | World t Li | Chile t Li | USGS report | Source PDF |
| ---: | ---: | ---: | ---: | --- |
| 1995 | 6,300 | 2,100 | 1996 | [MCS 1996](https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/atoms/files/mcs-1996ocr.pdf) |
| 1996 | 6,600 | 2,100 | 1997 | [MCS 1997](https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/atoms/files/mcs-1997ocr.pdf) |
| 1997 | 11,000 | 4,500 | 1998 | [MCS 1998](https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/atoms/files/mcs-1998ocr.pdf) |
| 1998 | 16,000 | 4,500 | 1999 | [MCS 1999](https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/atoms/files/mcs-1999ocr.pdf) |
| 1999 | 15,000 | 5,000 | 2000 | [MCS 2000](https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/mineral-pubs/mcs/mcs2000.pdf) |
| 2000 | 13,000 | 5,500 | 2001 | [MCS 2001](https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/mineral-pubs/mcs/mcs2001.pdf) |
| 2001 | 15,100 | 6,400 | 2002 | [MCS 2002](https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/mineral-pubs/mcs/mcs2002.pdf) |
| 2002 | 15,100 | 6,800 | 2003 | [MCS 2003](https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/mineral-pubs/mcs/mcs2003.pdf) |
| 2003 | 14,200 | 5,900 | 2004 | [MCS 2004](https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/mineral-pubs/mcs/mcs2004.pdf) |
| 2004 | 15,500 | 6,600 | 2005 | [MCS 2005](https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/mineral-pubs/mcs/mcs2005.pdf) |
| 2005 | 20,400 | 8,000 | 2006 | [MCS 2006](https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/mineral-pubs/mcs/mcs2006.pdf) |
| 2006 | 21,100 | 8,300 | 2007 | [MCS 2007](https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/mineral-pubs/mcs/mcs2007.pdf) |
| 2007 | 25,000 | 9,400 | 2008 | [MCS 2008](https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/mineral-pubs/mcs/mcs2008.pdf) |
| 2008 | 27,400 | 12,000 | 2009 | [MCS 2009](https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/mineral-pubs/mcs/mcs2009.pdf) |
| 2009 | 18,000 | 7,400 | 2010 | [MCS 2010](https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/mineral-pubs/mcs/mcs2010.pdf) |
| 2010 | 25,300 | 8,800 | 2011 | [MCS 2011](https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/mineral-pubs/mcs/mcs2011.pdf) |
| 2011 | 34,000 | 12,600 | 2012 | [MCS 2012](https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/mineral-pubs/mcs/mcs2012.pdf) |
| 2012 | 37,000 | 13,000 | 2013 | [MCS 2013](https://apps.usgs.gov/minerals-information-archives/mcs/mcs2013.pdf) |
| 2013 | 35,000 | 13,500 | 2014 | [MCS 2014](https://apps.usgs.gov/minerals-information-archives/mcs/mcs2014.pdf) |
| 2014 | 36,000 | 12,900 | 2015 | [MCS 2015](https://apps.usgs.gov/minerals-information-archives/mcs/mcs2015.pdf) |
| 2015 | 32,500 | 11,700 | 2016 | [MCS 2016](https://apps.usgs.gov/minerals-information-archives/mcs/mcs2016.pdf) |
| 2016 | 35,000 | 12,000 | 2017 | [MCS 2017](https://apps.usgs.gov/minerals-information-archives/mcs/mcs2017.pdf) |
| 2017 | 43,000 | 14,100 | 2018 | [MCS 2018](https://apps.usgs.gov/minerals-information-archives/mcs/mcs2018.pdf) |
| 2018 | 85,000 | 16,000 | 2019 | [MCS 2019](https://apps.usgs.gov/minerals-information-archives/mcs/mcs2019.pdf) |
| 2019 | 77,000 | 18,000 | 2020 | [MCS 2020](https://pubs.usgs.gov/periodicals/mcs2020/mcs2020.pdf) |
| 2020 | 82,000 | 18,000 | 2021 | [MCS 2021](https://pubs.usgs.gov/periodicals/mcs2021/mcs2021.pdf) |
| 2021 | 100,000 | 26,000 | 2022 | [MCS 2022](https://pubs.usgs.gov/periodicals/mcs2022/mcs2022.pdf) |
| 2022 | 130,000 | 39,000 | 2023 | [MCS 2023](https://pubs.usgs.gov/periodicals/mcs2023/mcs2023.pdf) |
| 2023 | 180,000 | 44,000 | 2024 | [MCS 2024](https://pubs.usgs.gov/periodicals/mcs2024/mcs2024.pdf) |
| 2024 | 240,000 | 49,000 | 2025 | [MCS 2025](https://pubs.usgs.gov/periodicals/mcs2025/mcs2025.pdf) |
| 2025 | 290,000 | 56,000 | 2026 | [MCS 2026](https://pubs.usgs.gov/periodicals/mcs2026/mcs2026.pdf) |

The latest version also shows a separate product-composition snapshot: in **2023**, 82% of Chilean mined lithium refined domestically became lithium carbonate, 11% lithium hydroxide, and the remainder lithium sulfate. The report gives the first two percentages and identifies sulfate as the remainder; 7% is calculated as `100 − 82 − 11`. Source: [ICCT/CMS, *Expanding the Lithium Value Chain in Chile* (2025), citing Benchmark Mineral Intelligence (2024b)](https://theicct.org/wp-content/uploads/2025/10/ID-391-%E2%80%93-Chile-lithium_report_final.pdf).

The product split is **not** a breakdown of 2025 production or of the 1995–2025 cumulative series.
