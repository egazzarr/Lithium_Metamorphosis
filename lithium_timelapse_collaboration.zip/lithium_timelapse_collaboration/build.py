"""Rebuild the two standalone HTML files from the shared, cited CSV data."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data' / 'chile_world_lithium_1995_2025.csv'
FIELDS = (
    'year',
    'world_annual_tonnes_Li',
    'chile_annual_tonnes_Li',
    'world_cumulative_since_1995_tonnes_Li',
    'chile_cumulative_since_1995_tonnes_Li',
)
VERSIONS = (
    ('01_original_plot', 'lithium_salt_timelapse_original'),
    ('02_latest_plot_and_compounds', 'lithium_salt_timelapse_latest'),
)

with DATA.open(newline='', encoding='utf-8') as stream:
    rows = list(csv.DictReader(stream))
assert len(rows) == 31 and rows[0]['year'] == '1995' and rows[-1]['year'] == '2025'
world_total = chile_total = 0
for row in rows:
    assert row['source_url'].startswith('https://')
    world_total += int(row['world_annual_tonnes_Li'])
    chile_total += int(row['chile_annual_tonnes_Li'])
    assert world_total == int(row['world_cumulative_since_1995_tonnes_Li'])
    assert chile_total == int(row['chile_cumulative_since_1995_tonnes_Li'])
embedded = [{field: int(row[field]) for field in FIELDS} for row in rows]
payload = json.dumps(embedded, separators=(',', ':'))

for directory, stem in VERSIONS:
    folder = ROOT / directory
    template = (folder / f'{stem}.template.html').read_text(encoding='utf-8')
    assert template.count('__EMBEDDED_DATA__') == 1
    output = folder / f'{stem}.html'
    output.write_text(template.replace('__EMBEDDED_DATA__', payload), encoding='utf-8')
    print(output.relative_to(ROOT))

with (ROOT / 'data' / 'chile_refining_mix_2023.csv').open(newline='', encoding='utf-8') as stream:
    shares = list(csv.DictReader(stream))
assert sum(int(row['share_percent']) for row in shares) == 100
source_lines = [
    '# Source register',
    '',
    "The two HTML versions use the same annual mine-production observations. Each pair of world and Chile values comes from the current-year mine-production column of the following year's USGS *Mineral Commodity Summaries* lithium chapter. Values are tonnes of contained Li. Cumulative figures in the CSV are running sums of the annual figures beginning in 1995.",
    '',
    '| Production year | World t Li | Chile t Li | USGS report | Source PDF |',
    '| ---: | ---: | ---: | ---: | --- |',
]
for row in rows:
    source_lines.append(
        f"| {row['year']} | {int(row['world_annual_tonnes_Li']):,} | "
        f"{int(row['chile_annual_tonnes_Li']):,} | {row['usgs_report_year']} | "
        f"[MCS {row['usgs_report_year']}]({row['source_url']}) |"
    )
source_lines += [
    '',
    'The latest version also shows a separate product-composition snapshot: in **2023**, 82% of Chilean mined lithium refined domestically became lithium carbonate, 11% lithium hydroxide, and the remainder lithium sulfate. The report gives the first two percentages and identifies sulfate as the remainder; 7% is calculated as `100 − 82 − 11`. Source: [ICCT/CMS, *Expanding the Lithium Value Chain in Chile* (2025), citing Benchmark Mineral Intelligence (2024b)](https://theicct.org/wp-content/uploads/2025/10/ID-391-%E2%80%93-Chile-lithium_report_final.pdf).',
    '',
    'The product split is **not** a breakdown of 2025 production or of the 1995–2025 cumulative series.',
]
(ROOT / 'SOURCES.md').write_text('\n'.join(source_lines) + '\n', encoding='utf-8')
print('SOURCES.md')
