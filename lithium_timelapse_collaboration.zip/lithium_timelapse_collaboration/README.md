# Lithium salt timelapse — collaboration package

Open either HTML file directly in a browser. Click the black screen to play; click again after the animation finishes to replay. Each HTML file contains its CSS, JavaScript, and embedded data. The pages request Lato from Google Fonts; if offline, the browser uses a sans-serif fallback.

## Versions

| Folder | File to open | What it shows |
| --- | --- | --- |
| `01_original_plot/` | `lithium_salt_timelapse_original.html` | The recovered first plot-only design: bold heading, round salt grains, and cumulative world and Chile mine production since 1995. |
| `02_latest_plot_and_compounds/` | `lithium_salt_timelapse_latest.html` | The latest design: annual world and Chile production, angular grains, a uniformly scaled left plot, and a grain-filled donut for Chile's 2023 refining mix. |

The first template was recovered from the original file-creation record and includes its final source-footer wording. Both versions embed the same 31 USGS annual observations. Their `.template.html` files are editable source with a `__EMBEDDED_DATA__` placeholder. To regenerate both HTML files after changing a template or the CSV, run `python3 build.py` from this folder.

## Data and sources

- `data/chile_world_lithium_1995_2025.csv` contains the annual world and Chile values, cumulative sums, source report year, and the exact USGS PDF URL used for **each** year. Units are metric tonnes of contained lithium. World includes Chile. The values come from each following year's USGS *Mineral Commodity Summaries* current-year mine-production column. Some published world totals exclude withheld U.S. output. [USGS lithium statistics and information](https://www.usgs.gov/centers/national-minerals-information-center/lithium-statistics-and-information).
- `data/chile_refining_mix_2023.csv` contains the 2023 Chile product shares: lithium carbonate 82%, lithium hydroxide 11%, and lithium sulfate 7%. The first two are reported in the [ICCT/CMS report, *Expanding the Lithium Value Chain in Chile*](https://theicct.org/wp-content/uploads/2025/10/ID-391-%E2%80%93-Chile-lithium_report_final.pdf), which attributes them to Benchmark Mineral Intelligence (2024b). Sulfate is the stated remainder, calculated as 100 − 82 − 11. The donut describes products of Chilean lithium refined in 2023; it is not a split of 2025 tonnes or of historical cumulative extraction.

The grains are an artistic representation and do not each correspond to a fixed mass. `visual_references/` holds the two powder images supplied for texture direction; neither image is embedded in the HTML or used as a data source.

See `02_latest_plot_and_compounds/NOTES.md` for fuller data and animation notes.
