# Lithium salt timelapse

Open `lithium_salt_timelapse.html` in a browser and click the black stage to play. Click after the sequence finishes to replay. Enter or Space also starts playback when the canvas has keyboard focus. The standalone page contains its CSS, JavaScript, and production data; Lato is requested from Google Fonts, with CSS font weight 250.

## What the plot shows

The left plot is **annual mine production**, in metric tonnes of contained lithium per year, from 1995 through 2025. The gray area is the published world total **including Chile**. The white Chile area is overlaid at the bottom; it is part of the world total, not an addition to it. Each reported year is a separate vertex joined to the next by a straight segment. The animation does not smooth or average the annual series. In 2025 the plotted values are 290,000 t Li for the world and 56,000 t Li for Chile.

The split transition scales the entire plot uniformly, preserving its aspect ratio and the fixed visual size of the angular grains. The Chile band empties from the 1995 side toward the 2025 side while grains leave from its later, higher right-hand region. The donut remains black until grains arrive and settle; arriving grains then move around the ring to their final positions. Gaps within both fills and loose grains beyond their edges are part of the texture.

The companion `chile_world_lithium_1995_2025.csv` contains all 31 annual observations, their cumulative sums retained for reference, the USGS report year, and a **point-level source URL in every row**. Each year's values come from the current-year mine-production column of the following year's USGS *Mineral Commodity Summaries* lithium chapter. The older OCR tables were checked against their country rows, and the later country and world-total rows were checked against extracted USGS tables. The plotted world series follows the USGS published totals, which can exclude withheld U.S. output. [USGS lithium statistics archive](https://www.usgs.gov/centers/national-minerals-information-center/lithium-statistics-and-information).

## Chile refining donut

The donut represents a **separate 2023 snapshot of the products into which lithium mined in Chile was refined domestically**: 82% lithium carbonate, 11% lithium hydroxide, and a 7% black gap for the remainder, lithium sulfate. These percentages are reported in [ICCT and CMS, *Expanding the Lithium Value Chain in Chile*, 2025, citing Benchmark Mineral Intelligence (2024b)](https://theicct.org/wp-content/uploads/2025/10/ID-391-%E2%80%93-Chile-lithium_report_final.pdf). The 7% is calculated as 100 − 82 − 11 because the report states "the rest" rather than printing a sulfate percentage. The values and their provenance also appear in `chile_refining_mix_2023.csv`. The donut is a percentage composition, not a conversion of the chart's 2025 tonnes, and the source does not establish that this mix applied throughout 1995–2025. The flowing grains are visual animation, not individually measured tonnes.

The 1995–2025 production data and the 2023 refined-product shares therefore have different years and denominators. The donut center and source link state the refining year on screen. The series stops at 2025 because 2026 annual USGS mine-production data were not available as of 25 October 2026.
